package com.example.proyectofinal_pescaenaguadulce

data class Zona(var nombre : String, var lugar: String, var imageZona : Int, var imageMap : Int)

