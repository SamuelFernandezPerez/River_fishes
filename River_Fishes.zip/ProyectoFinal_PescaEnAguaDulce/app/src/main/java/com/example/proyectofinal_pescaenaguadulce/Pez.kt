package com.example.proyectofinal_pescaenaguadulce

import java.io.Serializable

open class Pez(var clase: String, var zona: String) : Serializable


