package com.example.proyectofinal_pescaenaguadulce

class PezExistente(clase: String, zona: String, var imagePez : Int) : Pez(clase, zona) {
}


